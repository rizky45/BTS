ABOUT SC PORTAL SEKOLAH<br>
// @ Author -> YOGI PRASETYAWAN HADI<br>
// @ Facebook -> www.facebook.com/yogiyogs22<br>
// @ Code Name -> PF ( Portal Free )<br>
// Jika Ada Permasalahan Silahkan Hubungi Saya ^_^<br>
// Thanks to Skleton Framework , BLC TELKOM Klaten ^_^<br>
<br>
Saya harap rekan - rekan semua ikut mengembangkan portal yang saya buat ini
